from dataProc import *
from Threads import *


def Main():
    EncryptInput()


if __name__ == "__main__":
    Main()


def EncryptInput():
    Segment()
    getInfo()
    Crypt()


def DecryptMessage():
    DeCrypt()
    trim()
    Merge()
