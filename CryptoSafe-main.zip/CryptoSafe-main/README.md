# CryptoSafe: A secure file storage flask web app


<p align="center">
    <img src="image/README/1632356226536.png" width="400" />
    <br>
 </p>



This project presents the hybrid encryption scheme which combines the quick encryption schemes of encryption algorithms like AES, Blowfish, Triple DES, IDEA, Fernet. The proposed approach includes file splitting and merging mechanism along with Multi Threads to simultaneously encrypt files.

<p align="center">
    <img src="image/README/1626678446514.png" width="600" />
    <br>
 </p>

<p align="center">
    <img src="image/README/1626678611397.png" width="600" />
    <br>
 </p>


